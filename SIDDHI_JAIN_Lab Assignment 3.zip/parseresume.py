#!/usr/bin/env python3
import cgi
import json
from io import BytesIO
import fitz  # PyMuPDF for PDF parsing

form = cgi.FieldStorage()

def parse_candidate_resume(form):
    feedback_message = "Your Resume  Submitted Successfully."
    details = {
        'name': form.getvalue('name'),
        'email': form.getvalue('email'),
        'educationalQualifications': form.getvalue('educationalQualifications'),
        'skills': form.getvalue('skills'),
        'yearsOfExperience': form.getvalue('yearsOfExperience'),
        'jobPreference': form.getvalue('jobPreference'),
        'availability': form.getvalue('availability'),
    }

   

    # Return feedback and details
    return {'success': True, 'message': feedback_message, 'details': details}

# Main function
def main():
    feedback_result = parse_candidate_resume(form)
    if feedback_result['success']:
        feedback_message = feedback_result['message']
        details = feedback_result['details']
    else:
        feedback_message = feedback_result['message']
        details = {}

    print("Content-type: application/json\n")
    print(json.dumps({'feedback': feedback_message, 'details': details}))

if __name__ == "__main__":
    main()
