document.getElementById('candidateApplicationForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const formData = new FormData(this);

    fetch('/cgi-bin/parseresume.py', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert(data.feedback);
        if (data.details) {
            sessionStorage.setItem('formData', JSON.stringify(data.details));
            window.location.href = './success.html';
        }
    })
    .catch(error => console.error('Error:', error));
});
