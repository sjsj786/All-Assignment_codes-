document.addEventListener('DOMContentLoaded', function() {
  const form = document.getElementById('candidateApplicationForm');
  const emailInput = document.getElementById('email');
  const resumeInput = document.getElementById('resume');

  // Populate form fields with previously filled data
  for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      const value = localStorage.getItem(key);
      if (form.elements[key]) {
          form.elements[key].value = value;
      }
  }

  // Email validation function
  function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  // Form submit event listener
  form.addEventListener('submit', function(event) {
    // Prevent form submission
    event.preventDefault();

    // Retrieve form field values
    const name = document.getElementById('name').value.trim();
    const email = emailInput.value.trim();
    const educationalQualifications = document.getElementById('educationalQualifications').value.trim();
    const skills = document.getElementById('skills').value.trim();
    const yearsOfExperience = document.getElementById('yearsOfExperience').value.trim();
    const jobPreference = document.getElementById('jobPreference').value.trim();
    const availability = document.getElementById('availability').value.trim();
    const resume = resumeInput.value.trim();

    // Validate form fields
    if (name === '' || email === '' || educationalQualifications === '' || skills === '' || yearsOfExperience === '' || jobPreference === '' || availability === '' || resume === '') {
      alert('Please fill out all fields.');
      return;
    }

    if (!validateEmail(email)) {
      alert('Please enter a valid email address.');
      emailInput.focus();
      return;
    }

    if (isNaN(yearsOfExperience)) {
      alert('Years of Experience must be a number.');
      document.getElementById('yearsOfExperience').focus();
      return;
    }


  });

  // Redirect to resume upload page when "Choose file" button is clicked
  resumeInput.addEventListener('click', function() {
    window.location.href = 'upload_resume.html';
  });
});


