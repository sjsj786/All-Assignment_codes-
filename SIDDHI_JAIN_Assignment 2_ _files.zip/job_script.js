document.addEventListener('DOMContentLoaded', function() {
    const addSkillBtn = document.getElementById('addSkill');
    const addQualificationBtn = document.getElementById('addQualification');
  
    addSkillBtn.addEventListener('click', function() {
      const skillsContainer = document.getElementById('skillsContainer');
      const newSkillInput = document.createElement('input');
      newSkillInput.type = 'text';
      newSkillInput.classList.add('skillInput');
      newSkillInput.name = 'requiredSkills[]';
      newSkillInput.required = true;
      skillsContainer.appendChild(newSkillInput);
    });
  
    addQualificationBtn.addEventListener('click', function() {
      const qualificationsContainer = document.getElementById('qualificationsContainer');
      const newQualificationInput = document.createElement('input');
      newQualificationInput.type = 'text';
      newQualificationInput.classList.add('qualificationInput');
      newQualificationInput.name = 'educationalQualifications[]';
      newQualificationInput.required = true;
      qualificationsContainer.appendChild(newQualificationInput);
    });
  });
  