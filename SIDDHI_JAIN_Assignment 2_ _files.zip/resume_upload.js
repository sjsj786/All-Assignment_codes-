document.getElementById('resumeUploadForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const file = document.getElementById('resumeFile').files[0];
    if (!file) return;

    // Store the file in sessionStorage to pass it to the next page
    sessionStorage.setItem('uploadedResume', file.name);

    // Redirect to the candidate application portal
    window.location.href = './index.html';
});

document.addEventListener('DOMContentLoaded', function() {
    const uploadedResume = sessionStorage.getItem('uploadedResume');
    if (!uploadedResume) return;

    // Populate the file input with the uploaded resume name
    document.getElementById('uploadedResume').textContent = uploadedResume;

    // Populate the form fields with the previously filled data
    const formData = sessionStorage.getItem('formData');
    if (formData) {
        const data = JSON.parse(formData);
        for (const key in data) {
            document.getElementById(key).value = data[key];
        }
    }

    sessionStorage.removeItem('uploadedResume');
    sessionStorage.removeItem('formData');
});

document.getElementById('submitResume').addEventListener('click', function() {
    // Store the form data in sessionStorage
    const formData = new FormData(document.getElementById('candidateApplicationForm'));
    const data = {};
    for (const [key, value] of formData) {
        data[key] = value;
    }
    sessionStorage.setItem('formData', JSON.stringify(data));
});
