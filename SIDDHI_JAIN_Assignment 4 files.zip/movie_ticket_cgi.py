import cgi
def calculate_ticket_price(age, is_student):
 if age > 17 and age < 45:
    if is_student:
      return 0.9 * 100 # 10% discount for college students
   else:
     return 100 # Regular price
 elif age >= 60:
    return 0.95 * 100 # 5% discount for seniors
 elif age < 10:
   return 0.5 * 100 # 50% discount for children
 else:
   return 100 # Regular price

def main():
   print("Content-type: text/html\n")
   form = cgi.FieldStorage()
   name = form.getvalue("name")
   age = int(form.getvalue("age"))
   gender = form.getvalue("gender")
   movie = form.getvalue("movie")
   ticket_type = form.getvalue("ticket_type")
   is_student = form.getvalue("is_student") == "on"
   ticket_price = calculate_ticket_price(age, is_student)
   print("<html>")
   print("<head>")
   print("<title>Movie Ticket Booking Confirmation</title>")
   print("</head>")
   print("<body>")
   print("<h1>Movie Ticket Booking Confirmation</h1>")
   print("<p>Name: {}</p>".format(name))
   print("<p>Age: {}</p>".format(age))
   print("<p>Gender: {}</p>".format(gender))
   print("<p>Movie: {}</p>".format(movie))
   print("<p>Ticket Type: {}</p>".format(ticket_type))
   print("<p>Price: Rs. {:.2f}</p>".format(ticket_price))
   print("</body>")
   print("</html>")
if __name__ == "__main__":
  main()
